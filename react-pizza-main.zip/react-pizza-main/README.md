
<h1>:pizza: React Pizza</h1>

*Ecommerce template built using React and styled-components*
<br /> 

[Visit Site](https://nikkipeel.github.io/react-pizza)
<br />

:gem: **Features:**
- Mobile-responsive
- Slide-out menu
- Grid layout for display products


### Hero Section &darr;
<img src="src/images/hero.png" alt="hero section" width="100%" height="auto" />
<br />

### Navigation &darr;
<img src="src/images/navbar.png" alt="navigation" width="100%" height="auto" />
<br />

### Menu &darr;
<img src="src/images/pizza-menu.png" alt="pizza menu" width="100%" height="auto" />
<br />

### Featured/Specials &darr;
<img src="src/images/feature-final.png" alt="specials" width="100%" height="auto" />
<br />

### Desserts &darr;
<img src="src/images/dessert-menu.png" alt="dessert menu" width="100%" height="auto"/>
<br />

